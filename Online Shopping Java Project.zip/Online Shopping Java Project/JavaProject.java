
       import javax.swing.*;
       import java.awt.event.*;
       import java.awt.*; 
       import java.io.*;
       import javax.swing.filechooser.FileNameExtensionFilter;

    class MyFrame extends JFrame
    {
        JLabel l1;  
        JButton b1;

        public MyFrame()
        {
            super("MAIN FRAME"); 
            setSize(800, 500);
            setLocation(500, 300);
            setLayout(null);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setResizable(false);  
 
             l1 = new JLabel();
             l1.setBounds(150,30,500,300);    
             l1.setIcon(new ImageIcon("1.jpg"));  
             add(l1);       

             b1 = new JButton(" Welcome To My Java Project ");                 
             b1.setBounds(150, 370, 500, 40);
             b1.setFont(new Font("Consolas", Font.BOLD, 20));
             b1.setForeground(Color.RED);
             add(b1); 

             b1.addActionListener(new ActionListener()
             {
                   public void actionPerformed(ActionEvent e)
                   {      
                         MyFrame.this.setVisible(false);
                         new LoginFrame("admin", "admin");           
                   }
             });
            
             setVisible(true);
        }
    }

    class LoginFrame extends JFrame
    {
        JLabel l1, l2, l3;  
        JButton b1, b2, b3;
        JTextField t1;
        JPasswordField t2;
        String username , password; 

        public LoginFrame(String user, String password)
        {
            super("LOGIN FRAME"); 
            setSize(800, 500);
            setLocation(500, 300);
            setLayout(null);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setResizable(false);
  
            this.username = user;
            this.password = password;
 
            l1 = new JLabel();
            l1.setBounds(50,30,270,300);    
            l1.setIcon(ResizeImage(new ImageIcon("2.png")));  
            add(l1);       

            l2 = new JLabel(" USERNAME ");
            l2.setForeground(Color.RED);
            l2.setFont(new Font("Consolas", Font.BOLD, 23));
            l2.setBounds(380, 80, 130, 40);
            add(l2);
 
            t1 = new JTextField();
            t1.setBounds(530, 80, 200, 30);
            add(t1);  

            l3 = new JLabel(" PASSWORD ");
            l3.setForeground(Color.RED);
            l3.setFont(new Font("Consolas", Font.BOLD, 23));
            l3.setBounds(380, 150, 130, 40);
            add(l3);
 
            t2 = new JPasswordField();
            t2.setBounds(530, 150, 200, 30);
            add(t2);  
           
            b1 = new JButton(" LOGIN ");                 
            b1.setBounds(390, 240, 150, 40);
            b1.setFont(new Font("Consolas", Font.BOLD, 20));
            b1.setForeground(Color.RED);
            add(b1); 

            b2 = new JButton(" SIGN UP ");                 
            b2.setBounds(580, 240, 150, 40);
            b2.setFont(new Font("Consolas", Font.BOLD, 20));
            b2.setForeground(Color.RED);
            add(b2); 

            b1.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {

 	if(t1.getText().equals("") || t2.getText().equals(""))
 	{
JOptionPane.showMessageDialog(LoginFrame.this,"INVALID CREDENTIALS", "ERROR",  JOptionPane.ERROR_MESSAGE);
                       return;
 	}
        else if((t1.getText().equalsIgnoreCase(LoginFrame.this.username) && t2.getText().equalsIgnoreCase(LoginFrame.this.password)) || (t1.getText().equals("admin") && t2.getText().equals("admin")) )
 	{
JOptionPane.showMessageDialog(LoginFrame.this,"LOGIN SUCCESSFUL", "MESSAGE",  JOptionPane.PLAIN_MESSAGE);

                 LoginFrame.this.setVisible(false);
                    new Frame4();           
        }
        else
        {
JOptionPane.showMessageDialog(LoginFrame.this,"PLEASE SIGN UP FIRST!", "MESSAGE",  JOptionPane.PLAIN_MESSAGE);
        } 
                }
            });

            b2.addActionListener(new ActionListener()
            {
                 public void actionPerformed(ActionEvent e)
                 {
                         LoginFrame.this.setVisible(false);
                         new Frame3();                       
                 }
            });

            setVisible(true);
        }

        public ImageIcon ResizeImage(ImageIcon icon)
        {
             ImageIcon MyImage = icon;
             Image img = MyImage.getImage();
             Image newImg = img.getScaledInstance(l1.getWidth(), l1.getHeight(), Image.SCALE_SMOOTH);
             ImageIcon image = new ImageIcon(newImg);
                  return image;
        }
    }

    class Frame4 extends JFrame
    {
        JLabel l1, l2, l3, l4;
        JCheckBox cb1, cb2, cb3, cb4;
        JButton b1 , b2; 
  
        public Frame4()
        {
            super("BUY PLANTS"); 
            setSize(950, 500);
            setLocation(250, 300);
            setLayout(null);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setResizable(false);  
 
            l1 = new JLabel();
            l1.setBounds(30, 20, 200, 200);
            l1.setIcon(ResizeImage(new ImageIcon("sprayer.jpg")));
            add(l1);
           
            cb1 = new JCheckBox("Sprayer(Rs.1000)");
            cb1.setBounds(40, 230, 200, 30);
            add(cb1); 

            l2 = new JLabel();
            l2.setBounds(250, 20, 200, 200);
            l2.setIcon(ResizeImage(new ImageIcon("Fork.jpg")));
            add(l2);
           
            cb2 = new JCheckBox("Farm Fork (Rs.2500)");
            cb2.setBounds(260, 230, 200, 30);
            add(cb2); 

            l3 = new JLabel();
            l3.setBounds(480, 20, 200, 200);
            l3.setIcon(ResizeImage(new ImageIcon("shovel.jpg")));
            add(l3);
           
            cb3 = new JCheckBox("Shovel (Rs.2000)");
            cb3.setBounds(480, 230, 200, 30);
            add(cb3); 

            l4 = new JLabel();
            l4.setBounds(700, 20, 200, 200);
            l4.setIcon(ResizeImage(new ImageIcon("Tiler.jpg")));
            add(l4);
           
            cb4 = new JCheckBox(" Tiler (Rs.3000)");
            cb4.setBounds(700, 230, 200, 30);
            add(cb4); 

            b1 = new JButton("BUY SELECTED ITEMS"); 
            b1.setBounds(100, 350, 300, 40);
            add(b1);

            b2 = new JButton("SELL OLD ITEMS"); 
            b2.setBounds(500, 350, 300, 40);
            add(b2);

            b1.addActionListener(new ActionListener()
            {
                 public void actionPerformed(ActionEvent e) 
                 {
                         float price = 0;

               if(!cb1.isSelected() && !cb2.isSelected() && !cb3.isSelected() && !cb4.isSelected())
               {
        JOptionPane.showMessageDialog(Frame4.this," Please Select Plants","MESSAGE",JOptionPane.PLAIN_MESSAGE); 
                          return;
               }

                      if(cb1.isSelected())
                      {
                          price += 1000;                                                 
                      }
                      if(cb2.isSelected())
                      {
                          price += 2500;                                                 
                      }
                      if(cb3.isSelected())
                      {
                          price += 2000;                                                 
                      }
                      if(cb4.isSelected())
                      {
                          price += 3000;                                                 
                      }

        JOptionPane.showMessageDialog(Frame4.this," Total Price = "+price+"\n Selected items will be deliverd in 3 working days!\n Thank You!","MESSAGE",JOptionPane.PLAIN_MESSAGE); 

                        cb1.setSelected(false);
                        cb2.setSelected(false);
                        cb3.setSelected(false);
                        cb4.setSelected(false);
                 }
            });          

            b2.addActionListener(new ActionListener()
            {
                 public void actionPerformed(ActionEvent e) 
                 {
                         Frame4.this.setVisible(false);
                         new Frame5();
                 }
            });

            setVisible(true);
        }

        public ImageIcon ResizeImage(ImageIcon icon)
        {
             ImageIcon MyImage = icon;
             Image img = MyImage.getImage();
             Image newImg = img.getScaledInstance(l1.getWidth(), l1.getHeight(), Image.SCALE_SMOOTH);
             ImageIcon image = new ImageIcon(newImg);
                  return image;
        }
    }

   class Frame5 extends JFrame
   {
         JLabel l1,l2,l3,l4,l5,l6,l7;
         JTextField t1,t2,t3,t4;
         JButton b1, b2, b3;
   
         public Frame5()
         {
             super("UPLOAD DETAILS");
             setSize(700 , 450);
             setResizable(false);
             setLocation(500, 300); 
             setLayout(null);
             setDefaultCloseOperation(EXIT_ON_CLOSE);

              l1 = new JLabel("Enter Tool Name  ");
              l1.setBounds(80 , 50 , 150 , 30);
              add(l1); 

              t1 = new JTextField();
              t1.setBounds(230 , 50 , 200 , 30);
              add(t1); 

              l2 = new JLabel("Enter Category  ");
              l2.setBounds(80 , 100 , 150 , 30);
              add(l2); 

              t2 = new JTextField();
              t2.setBounds(230 , 100 , 200 , 30);
              add(t2); 

              l3 = new JLabel("Enter Price  ");
              l3.setBounds(80 , 150 , 150 , 30);
              add(l3); 

              t3 = new JTextField();
              t3.setBounds(230 , 150 , 200 , 30);
              add(t3); 

              b2 = new JButton("SUBMIT DETAILS");
              b2.setBounds(100 , 230 , 200, 30);
              add(b2);

              l6 = new JLabel(); 
              l6.setBounds(450 , 30 , 180, 180);
              add(l6); 

              b1 = new JButton("UPLOAD PHOTO");
              b1.setBounds(470 , 230 , 150, 30);
              add(b1);

              b3 = new JButton("GO BACK");
              b3.setBounds(270 , 300 , 150, 40);
              add(b3);

            b3.addActionListener(new ActionListener()
            {
                 public void actionPerformed(ActionEvent e) 
                 {
                         Frame5.this.setVisible(false);
                         new Frame4();
                 }
            });
                
       b2.addActionListener(new ActionListener()
       {
             public void actionPerformed(ActionEvent ae)
             {
                     if(t1.getText().equals("") || t2.getText().equals("") || t3.getText().equals("")) 
                     {
        JOptionPane.showMessageDialog(Frame5.this,"Please Enter Details","MESSAGE",JOptionPane.PLAIN_MESSAGE); 
                             return;
                     } 
                     else
                     {
        JOptionPane.showMessageDialog(Frame5.this,"Item Details Sent for varification","MESSAGE",JOptionPane.PLAIN_MESSAGE); 
                     }
            }
       });  

     b1.addActionListener(new ActionListener()
     {
        public void actionPerformed(ActionEvent e)
        {
          JFileChooser file = new JFileChooser();

  file.setCurrentDirectory(new File(System.getProperty("user.home")));
         
     FileNameExtensionFilter filter = new FileNameExtensionFilter("*.Images", "jpg","gif","png","jpeg");
    
          file.addChoosableFileFilter(filter);
          int result = file.showSaveDialog(null);
    
      if(result == JFileChooser.APPROVE_OPTION)
      {
              File selectedFile = file.getSelectedFile();
              String path = selectedFile.getAbsolutePath();
              l6.setIcon(ResizeImage(path));
      }
      else if(result == JFileChooser.CANCEL_OPTION)
      {
              System.out.println("No File Select");
      }
        }
    });
                setVisible(true);
         } 

    public ImageIcon ResizeImage(String ImagePath)
    {
        ImageIcon MyImage = new ImageIcon(ImagePath);
        Image img = MyImage.getImage();
        Image newImg = img.getScaledInstance(l6.getWidth(), l6.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(newImg);
        return image;
    }
   }

    class Frame3 extends JFrame
    {
        JLabel l1, l2, l3;
        JTextField t1;
        JPasswordField t2, t3;
        JButton b1, b2;
  
        public Frame3()
        {
            super("SIGN UP PAGE"); 
            setSize(500, 400);
            setLocation(500, 300);
            setLayout(null);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setResizable(false);  

            l1 = new JLabel(" Enter Username : ");
            l1.setBounds(20,20,150,30);
            add(l1);

            t1 = new JTextField();
            t1.setBounds(190,20, 200, 30);
            add(t1);

            l2 = new JLabel(" Enter Password : ");
            l2.setBounds(20,70,150,30);
            add(l2);

            t2 = new JPasswordField();
            t2.setBounds(190,70, 200, 30);
            add(t2);

            l3 = new JLabel(" Retype Password : ");
            l3.setBounds(20,120,150,30);
            add(l3);

            t3 = new JPasswordField();
            t3.setBounds(190,120, 200, 30);
            add(t3);

            b1 = new JButton("CREATE AN ACCOUNT");
            b1.setBounds(20, 180, 180, 30);
            add(b1); 

            b2 = new JButton("CLEAR ALL");
            b2.setBounds(220, 180, 160, 30);
            add(b2); 

            b1.addActionListener(new ActionListener()
            {
                 public void actionPerformed(ActionEvent e)
                 {

 	if(t1.getText().equals("") || t2.getText().equals("") || t3.getText().equals(""))
 	{
JOptionPane.showMessageDialog(Frame3.this, "INVALID CREDENTIALS","ERROR", JOptionPane.ERROR_MESSAGE);
                       return;
 	}
 	else if(!(t2.getText().equals(t3.getText())))
 	{
JOptionPane.showMessageDialog(Frame3.this, "Retype Password is incorrect", "ERROR", JOptionPane.ERROR_MESSAGE);
                       return;
 	}
  else
 	{
JOptionPane.showMessageDialog(Frame3.this, "ACCOUNT CREATED SUCCESSFULLY!", "MESSAGE" ,  JOptionPane.PLAIN_MESSAGE);

                         Frame3.this.setVisible(false);
                         new LoginFrame(t1.getText(), t2.getText());
 	}
                 }
            });

            setVisible(true); 
        }
    }

   public class JavaProject
   {
       public static void main(String [] args)
       {
            new MyFrame();
       }
   }
